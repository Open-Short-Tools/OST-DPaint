# This program is free software; you can redistribute it and/or modify
# it under the terms of the GNU General Public License as published by
# the Free Software Foundation; either version 3 of the License, or
# (at your option) any later version.
#
# This program is distributed in the hope that it will be useful, but
# WITHOUT ANY WARRANTY; without even the implied warranty of
# MERCHANTIBILITY or FITNESS FOR A PARTICULAR PURPOSE. See the GNU
# General Public License for more details.
#
# You should have received a copy of the GNU General Public License
# along with this program. If not, see <http://www.gnu.org/licenses/>.

bl_info = {
    "name" : "OST DPaint",
    "author" : "Drawnesteban", 
    "description" : "A quick and simple panel to manage Dynamic Paint settings",
    "blender" : (4, 2, 0),
    "version" : (0, 0, 5),
    "location" : "https://github.com/Open-Short-Tools/OST-DPaint/blob/main/README.md",
    "warning" : "",
    "doc_url": "", 
    "tracker_url": "", 
    "category" : "3D View" 
}


import bpy
import bpy.utils.previews


addon_keymaps = {}
_icons = None
class SNA_OT_Add_7Cda1(bpy.types.Operator):
    bl_idname = "sna.add_7cda1"
    bl_label = "Add"
    bl_description = ""
    bl_options = {"REGISTER", "UNDO"}

    @classmethod
    def poll(cls, context):
        if bpy.app.version >= (3, 0, 0) and True:
            cls.poll_message_set('')
        return not False

    def execute(self, context):
        exec("bpy.ops.object.modifier_add(type='DYNAMIC_PAINT')")
        return {"FINISHED"}

    def invoke(self, context, event):
        return self.execute(context)


class SNA_OT_Remove_1Dd59(bpy.types.Operator):
    bl_idname = "sna.remove_1dd59"
    bl_label = "Remove"
    bl_description = ""
    bl_options = {"REGISTER", "UNDO"}

    @classmethod
    def poll(cls, context):
        if bpy.app.version >= (3, 0, 0) and True:
            cls.poll_message_set('')
        return not False

    def execute(self, context):
        exec('bpy.ops.object.modifier_remove(modifier="Dynamic Paint")')
        return {"FINISHED"}

    def invoke(self, context, event):
        return self.execute(context)


class SNA_PT_OST_DPAINT_98EAC(bpy.types.Panel):
    bl_label = 'OST DPaint'
    bl_idname = 'SNA_PT_OST_DPAINT_98EAC'
    bl_space_type = 'VIEW_3D'
    bl_region_type = 'UI'
    bl_context = ''
    bl_category = 'OST DPaint'
    bl_order = 0
    bl_ui_units_x=0

    @classmethod
    def poll(cls, context):
        return not (False)

    def draw_header(self, context):
        layout = self.layout
        layout.label(text='', icon_value=134)

    def draw(self, context):
        layout = self.layout
        col_0894E = layout.column(heading='', align=False)
        col_0894E.alert = False
        col_0894E.enabled = True
        col_0894E.active = True
        col_0894E.use_property_split = False
        col_0894E.use_property_decorate = False
        col_0894E.scale_x = 1.0
        col_0894E.scale_y = 1.0
        col_0894E.alignment = 'Expand'.upper()
        col_0894E.operator_context = "INVOKE_DEFAULT" if True else "EXEC_DEFAULT"
        row_618CC = col_0894E.row(heading='ADD/REMOVE', align=True)
        row_618CC.alert = False
        row_618CC.enabled = True
        row_618CC.active = True
        row_618CC.use_property_split = False
        row_618CC.use_property_decorate = False
        row_618CC.scale_x = 1.0
        row_618CC.scale_y = 1.0
        row_618CC.alignment = 'Expand'.upper()
        row_618CC.operator_context = "INVOKE_DEFAULT" if True else "EXEC_DEFAULT"
        op = row_618CC.operator('sna.add_7cda1', text='Add', icon_value=254, emboss=True, depress=False)
        op = row_618CC.operator('sna.remove_1dd59', text='Remove', icon_value=253, emboss=True, depress=False)
        row_3C9D0 = col_0894E.row(heading='', align=True)
        row_3C9D0.alert = False
        row_3C9D0.enabled = True
        row_3C9D0.active = True
        row_3C9D0.use_property_split = False
        row_3C9D0.use_property_decorate = False
        row_3C9D0.scale_x = 1.0
        row_3C9D0.scale_y = 1.0
        row_3C9D0.alignment = 'Expand'.upper()
        row_3C9D0.operator_context = "INVOKE_DEFAULT" if True else "EXEC_DEFAULT"
        op = row_3C9D0.operator('sna.brush_0bfad', text='Brush', icon_value=67, emboss=True, depress=False)
        op = row_3C9D0.operator('sna.canvas_d6489', text='Canvas', icon_value=128, emboss=True, depress=False)
        row_3C9D0.prop(bpy.context.view_layer.objects.active.modifiers['Dynamic Paint'], 'ui_type', text='', icon_value=0, emboss=True)
        col_0894E.separator(factor=1.0)
        op = col_0894E.operator('mesh.subdivide', text='Subdivide', icon_value=471, emboss=True, depress=False)


class SNA_OT_Canvas_D6489(bpy.types.Operator):
    bl_idname = "sna.canvas_d6489"
    bl_label = "Canvas"
    bl_description = ""
    bl_options = {"REGISTER", "UNDO"}

    @classmethod
    def poll(cls, context):
        if bpy.app.version >= (3, 0, 0) and True:
            cls.poll_message_set('')
        return not False

    def execute(self, context):
        exec("bpy.ops.dpaint.type_toggle(type='CANVAS')")
        return {"FINISHED"}

    def invoke(self, context, event):
        return self.execute(context)


class SNA_OT_Brush_0Bfad(bpy.types.Operator):
    bl_idname = "sna.brush_0bfad"
    bl_label = "Brush"
    bl_description = ""
    bl_options = {"REGISTER", "UNDO"}

    @classmethod
    def poll(cls, context):
        if bpy.app.version >= (3, 0, 0) and True:
            cls.poll_message_set('')
        return not False

    def execute(self, context):
        exec("bpy.ops.dpaint.type_toggle(type='BRUSH')")
        return {"FINISHED"}

    def invoke(self, context, event):
        return self.execute(context)


class SNA_OT_Sub_F1F02(bpy.types.Operator):
    bl_idname = "sna.sub_f1f02"
    bl_label = "Sub"
    bl_description = ""
    bl_options = {"REGISTER", "UNDO"}

    @classmethod
    def poll(cls, context):
        if bpy.app.version >= (3, 0, 0) and True:
            cls.poll_message_set('')
        return not False

    def execute(self, context):
        exec('bpy.ops.mesh.subdivide()')
        return {"FINISHED"}

    def invoke(self, context, event):
        return self.execute(context)


class SNA_OT_Physics_Tab_0A8E0(bpy.types.Operator):
    bl_idname = "sna.physics_tab_0a8e0"
    bl_label = "Physics Tab"
    bl_description = ""
    bl_options = {"REGISTER", "UNDO"}

    @classmethod
    def poll(cls, context):
        if bpy.app.version >= (3, 0, 0) and True:
            cls.poll_message_set('')
        return not False

    def execute(self, context):
        exec("bpy.context.space_data.context = 'PHYSICS'")
        return {"FINISHED"}

    def invoke(self, context, event):
        return self.execute(context)


def register():
    global _icons
    _icons = bpy.utils.previews.new()
    bpy.utils.register_class(SNA_OT_Add_7Cda1)
    bpy.utils.register_class(SNA_OT_Remove_1Dd59)
    bpy.utils.register_class(SNA_PT_OST_DPAINT_98EAC)
    bpy.utils.register_class(SNA_OT_Canvas_D6489)
    bpy.utils.register_class(SNA_OT_Brush_0Bfad)
    bpy.utils.register_class(SNA_OT_Sub_F1F02)
    bpy.utils.register_class(SNA_OT_Physics_Tab_0A8E0)


def unregister():
    global _icons
    bpy.utils.previews.remove(_icons)
    wm = bpy.context.window_manager
    kc = wm.keyconfigs.addon
    for km, kmi in addon_keymaps.values():
        km.keymap_items.remove(kmi)
    addon_keymaps.clear()
    bpy.utils.unregister_class(SNA_OT_Add_7Cda1)
    bpy.utils.unregister_class(SNA_OT_Remove_1Dd59)
    bpy.utils.unregister_class(SNA_PT_OST_DPAINT_98EAC)
    bpy.utils.unregister_class(SNA_OT_Canvas_D6489)
    bpy.utils.unregister_class(SNA_OT_Brush_0Bfad)
    bpy.utils.unregister_class(SNA_OT_Sub_F1F02)
    bpy.utils.unregister_class(SNA_OT_Physics_Tab_0A8E0)
